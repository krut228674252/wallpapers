package com.example.livewall

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val PALETTE = listOf(
    Color(0xFF6750A4), Color(0xFFE91E63), Color(0xFFF44336), Color(0xFFFF9800),
    Color(0xFFFFC107), Color(0xFF4CAF50), Color(0xFF009688), Color(0xFF00BCD4),
    Color(0xFF2196F3), Color(0xFF3F51B5), Color(0xFF9C27B0), Color(0xFF795548)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen() }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    var st by remember { mutableStateOf(Prefs.read(ctx)) }
    fun update(n: Cfg) {
        st = n
        Prefs.write(ctx, n)
    }

    val time = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (n - last > 33_000_000L) {
                    last = n
                    time.value = (n - start) / 1e9f
                }
            }
        }
    }

    val hue = remember(st.color) {
        val a = FloatArray(3)
        AColor.colorToHSV(st.color, a)
        a[0]
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "Живые\nобои",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box {
                Preview(st.style, st, time, Modifier.fillMaxWidth().height(360.dp), RoundedCornerShape(48.dp))
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
                ) {
                    Text(
                        Renderer.NAMES[st.style],
                        Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        items(Renderer.NAMES.size) { i ->
            Tile(i, st, time) { update(st.copy(style = i)) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Surface(
                shape = RoundedCornerShape(32.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Цвет", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        PALETTE.forEach { c ->
                            Swatch(c, st.color == c.toArgb()) { update(st.copy(color = c.toArgb())) }
                        }
                    }
                    Text("Оттенок")
                    Slider(
                        value = hue,
                        onValueChange = { update(st.copy(color = AColor.HSVToColor(floatArrayOf(it, 0.7f, 0.9f)))) },
                        valueRange = 0f..360f
                    )
                    Text("Скорость")
                    Slider(
                        value = st.speed,
                        onValueChange = { update(st.copy(speed = it)) },
                        valueRange = 0.2f..3f
                    )
                    Text("Плотность")
                    Slider(
                        value = st.density,
                        onValueChange = { update(st.copy(density = it)) },
                        valueRange = 0f..1f
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Тёмный фон")
                        Switch(checked = st.dark, onCheckedChange = { update(st.copy(dark = it)) })
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Button(
                onClick = {
                    val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                        .putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(ctx, LiveWallpaper::class.java)
                        )
                    try {
                        ctx.startActivity(i)
                    } catch (e: Exception) {
                        ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                    }
                },
                modifier = Modifier.fillMaxWidth().height(68.dp),
                shape = RoundedCornerShape(34.dp)
            ) {
                Text("Установить обои", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun Preview(style: Int, st: Cfg, time: State<Float>, modifier: Modifier, shape: Shape) {
    val r = remember { Renderer() }
    val pr = st.params()
    Canvas(modifier.clip(shape)) {
        drawIntoCanvas { c -> r.draw(c.nativeCanvas, size.width, size.height, time.value, style, pr) }
    }
}

@Composable
fun Tile(i: Int, st: Cfg, time: State<Float>, onClick: () -> Unit) {
    val sel = st.style == i
    val corner by animateDpAsState(
        if (sel) 56.dp else 20.dp,
        spring(dampingRatio = 0.5f, stiffness = 300f),
        label = "corner"
    )
    val sc by animateFloatAsState(
        if (sel) 1f else 0.95f,
        spring(dampingRatio = 0.5f, stiffness = 300f),
        label = "scale"
    )
    val shape = RoundedCornerShape(maxOf(corner.value, 0f).dp)
    Box(
        Modifier.fillMaxWidth().aspectRatio(0.8f).scale(sc).clip(shape).clickable(onClick = onClick)
    ) {
        Preview(i, st, time, Modifier.fillMaxSize(), shape)
        if (sel) Box(Modifier.fillMaxSize().border(4.dp, MaterialTheme.colorScheme.primary, shape))
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
        ) {
            Text(
                Renderer.NAMES[i],
                Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
fun Swatch(c: Color, selected: Boolean, onClick: () -> Unit) {
    val size by animateDpAsState(
        if (selected) 52.dp else 38.dp,
        spring(dampingRatio = 0.45f, stiffness = 400f),
        label = "swatch"
    )
    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(maxOf(size.value, 0f).dp).clip(CircleShape).background(c).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

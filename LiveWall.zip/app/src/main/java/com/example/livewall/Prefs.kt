package com.example.livewall

import android.content.Context

data class Cfg(
    val style: Int = 0,
    val color: Int = 0xFF6750A4.toInt(),
    val speed: Float = 1f,
    val density: Float = 0.5f,
    val dark: Boolean = true
) {
    fun params() = Params(color, speed, density, dark)
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("wall", Context.MODE_PRIVATE)

    fun read(c: Context): Cfg {
        val s = sp(c)
        val d = Cfg()
        return Cfg(
            s.getInt("style", d.style),
            s.getInt("color", d.color),
            s.getFloat("speed", d.speed),
            s.getFloat("density", d.density),
            s.getBoolean("dark", d.dark)
        )
    }

    fun write(c: Context, v: Cfg) {
        sp(c).edit()
            .putInt("style", v.style)
            .putInt("color", v.color)
            .putFloat("speed", v.speed)
            .putFloat("density", v.density)
            .putBoolean("dark", v.dark)
            .apply()
    }
}

package com.example.livewall

import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService

class LiveWallpaper : WallpaperService() {
    override fun onCreateEngine(): Engine = WallEngine()

    inner class WallEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val renderer = Renderer()
        private var visible = false
        private val t0 = SystemClock.uptimeMillis()
        private val ticker = Runnable { frame() }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(ticker)
            if (visible) frame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(ticker)
            super.onDestroy()
        }

        private fun frame() {
            if (!visible) return
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) {
                    val cfg = Prefs.read(this@LiveWallpaper)
                    val t = (SystemClock.uptimeMillis() - t0) / 1000f
                    renderer.draw(c, c.width.toFloat(), c.height.toFloat(), t, cfg.style, cfg.params())
                }
            } catch (e: Exception) {
                // поверхность могла исчезнуть
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
                }
            }
            handler.removeCallbacks(ticker)
            if (visible) handler.postDelayed(ticker, 33)
        }
    }
}

package com.example.livewall

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class Params(val color: Int, val speed: Float, val density: Float, val dark: Boolean)

/** Рисует все 10 обоев. Один экземпляр = один поток рисования. */
class Renderer {
    companion object {
        val NAMES = listOf(
            "Блобы", "Волны", "Аврора", "Частицы", "Геометрия",
            "Рябь", "Сетка", "Спираль", "Свип", "Печеньки"
        )
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val hsv = FloatArray(3)
    private val mx = Matrix()
    private val rect = RectF()

    private fun shift(c: Int, dh: Float, s: Float, v: Float): Int {
        Color.colorToHSV(c, hsv)
        hsv[0] = (hsv[0] + dh + 360f) % 360f
        hsv[1] = (hsv[1] * s).coerceIn(0f, 1f)
        hsv[2] = (hsv[2] * v).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    private fun al(c: Int, a: Float): Int =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun fr(x: Float): Float = x - floor(x)

    fun draw(cv: Canvas, w: Float, h: Float, tRaw: Float, style: Int, pr: Params) {
        val t = tRaw * pr.speed
        val u = min(w, h) / 1080f
        val c1 = pr.color
        val c2 = shift(c1, 40f, 1f, 1f)
        val c3 = shift(c1, -40f, 1f, 1f)
        val cols = intArrayOf(c1, c2, c3)
        val bg = if (pr.dark) shift(c1, 0f, 0.6f, 0.13f) else shift(c1, 0f, 0.12f, 2f)

        p.shader = null
        p.style = Paint.Style.FILL
        p.strokeWidth = 0f
        cv.drawColor(bg)

        when (style) {
            0 -> { // Блобы
                val n = 3 + (pr.density * 5f).toInt()
                val big = max(w, h)
                for (i in 0 until n) {
                    val a = t * 0.25f + i * 1.7f
                    val cx = w * (0.5f + 0.4f * sin(a * 1.1f + i))
                    val cy = h * (0.5f + 0.4f * cos(a * 0.9f + i * 2f))
                    val r = big * (0.28f + 0.08f * sin(a + i))
                    val c = cols[i % 3]
                    p.shader = RadialGradient(cx, cy, r, al(c, 0.9f), al(c, 0f), Shader.TileMode.CLAMP)
                    cv.drawCircle(cx, cy, r, p)
                }
                p.shader = null
            }
            1 -> { // Волны
                val n = 3 + (pr.density * 4f).toInt()
                for (i in 0 until n) {
                    val base = h * (0.3f + 0.65f * i / n)
                    val amp = h * 0.035f * (1f + i * 0.3f)
                    path.reset()
                    path.moveTo(0f, h)
                    var x = 0f
                    while (x <= w + 16f) {
                        val y = base +
                            amp * sin(x / w * (5f + i) + t * (0.6f + i * 0.2f)) +
                            amp * 0.5f * sin(x / w * 9f - t * 0.8f)
                        path.lineTo(x, y)
                        x += 16f
                    }
                    path.lineTo(w, h)
                    path.close()
                    p.color = al(cols[i % 3], 0.4f)
                    cv.drawPath(path, p)
                }
            }
            2 -> { // Аврора
                val n = 3 + (pr.density * 4f).toInt()
                for (i in 0 until n) {
                    val c = cols[i % 3]
                    val bw = w / n * 1.5f
                    val x = w * (i + 0.5f) / n + w * 0.08f * sin(t * 0.5f + i * 1.3f)
                    val top = h * (0.12f + 0.12f * sin(t * 0.4f + i))
                    val bot = h * 0.92f
                    p.shader = LinearGradient(
                        0f, top, 0f, bot,
                        intArrayOf(al(c, 0f), al(c, 0.7f), al(c, 0f)),
                        floatArrayOf(0f, 0.45f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    cv.drawRoundRect(x - bw / 2f, top, x + bw / 2f, bot, bw / 2f, bw / 2f, p)
                }
                p.shader = null
            }
            3 -> { // Частицы
                val m = 20 + (pr.density * 70f).toInt()
                for (i in 0 until m) {
                    val fx = fr(i * 0.618034f)
                    val ph = fr(i * 0.381966f + 0.3f)
                    val sp = 0.02f + 0.05f * fr(i * 0.7071f)
                    val y = h * (1.1f - 1.2f * fr(ph + t * sp))
                    val x = w * fx + 30f * u * sin(t * 0.8f + i)
                    val r = (5f + 18f * fr(i * 0.3f)) * u + 1f
                    p.color = al(cols[i % 3], 0.75f)
                    cv.drawCircle(x, y, r, p)
                }
            }
            4 -> { // Геометрия
                val n = 4 + (pr.density * 6f).toInt()
                p.style = Paint.Style.STROKE
                p.strokeWidth = 8f * u + 1f
                for (i in 0 until n) {
                    val s = min(w, h) * 0.09f * (i + 1.5f)
                    p.color = al(cols[i % 3], 0.8f)
                    cv.save()
                    cv.translate(w / 2f, h / 2f)
                    cv.rotate((if (i % 2 == 0) 1f else -1f) * t * 8f + i * 9f)
                    rect.set(-s, -s, s, s)
                    cv.drawRoundRect(rect, s * 0.35f, s * 0.35f, p)
                    cv.restore()
                }
            }
            5 -> { // Рябь
                val n = 4 + (pr.density * 5f).toInt()
                p.style = Paint.Style.STROKE
                val cx = w / 2f + w * 0.1f * sin(t * 0.3f)
                val cy = h * 0.45f + h * 0.05f * cos(t * 0.25f)
                for (i in 0 until n) {
                    val ph = fr(t * 0.12f + i.toFloat() / n)
                    p.strokeWidth = (6f + 30f * ph) * u + 1f
                    p.color = al(cols[i % 3], 0.8f * (1f - ph))
                    cv.drawCircle(cx, cy, ph * max(w, h) * 0.8f, p)
                }
            }
            6 -> { // Сетка
                val nc = 4 + (pr.density * 4f).toInt()
                val cell = w / nc
                val nr = ceil(h / cell).toInt() + 1
                for (r in 0 until nr) {
                    for (c in 0 until nc) {
                        val ph = sin(t * 1.2f + (r + c) * 0.6f)
                        val s = cell * (0.28f + 0.17f * ph)
                        val cx = cell * (c + 0.5f)
                        val cy = cell * (r + 0.5f)
                        val rad = s * (0.5f + 0.5f * (ph + 1f) / 2f)
                        p.color = al(cols[(r + c) % 3], 0.85f)
                        cv.drawRoundRect(cx - s, cy - s, cx + s, cy + s, rad, rad, p)
                    }
                }
            }
            7 -> { // Спираль
                val n = 60 + (pr.density * 160f).toInt()
                val cx = w / 2f
                val cy = h / 2f
                val maxR = max(w, h) * 0.55f
                for (i in 0 until n) {
                    val a = i * 2.39996f + t * 0.3f
                    val rr = sqrt(i.toFloat() / n) * maxR
                    p.color = al(cols[i % 3], 0.9f)
                    cv.drawCircle(cx + rr * cos(a), cy + rr * sin(a), (3f + 14f * i / n) * u + 1f, p)
                }
            }
            8 -> { // Свип
                val cx = w / 2f
                val cy = h / 2f
                val sw = SweepGradient(
                    cx, cy,
                    intArrayOf(al(c1, 0.9f), al(c2, 0.9f), al(c3, 0.9f), al(c1, 0.9f)),
                    null
                )
                mx.reset()
                mx.setRotate(t * 15f, cx, cy)
                sw.setLocalMatrix(mx)
                p.shader = sw
                cv.drawRect(0f, 0f, w, h, p)
                p.shader = null
                val pulse = 1f + 0.15f * sin(t)
                p.color = bg
                cv.drawCircle(cx, cy, min(w, h) * 0.22f * pulse, p)
                p.color = al(c2, 0.9f)
                cv.drawCircle(cx, cy, min(w, h) * 0.1f * pulse, p)
            }
            9 -> { // Печеньки
                val n = 3 + (pr.density * 4f).toInt()
                for (i in n - 1 downTo 0) {
                    val r = min(w, h) * 0.16f * (i + 1.2f)
                    val lobes = 5 + i
                    val rot = t * 0.3f * (if (i % 2 == 0) 1f else -1f)
                    path.reset()
                    for (k in 0..96) {
                        val a = k * 2f * PI.toFloat() / 96f
                        val rr = r * (1f + 0.09f * sin(lobes * a + rot * 3f))
                        val x = w / 2f + rr * cos(a)
                        val y = h / 2f + rr * sin(a)
                        if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close()
                    p.color = al(cols[i % 3], 0.55f)
                    cv.drawPath(path, p)
                }
            }
            else -> {}
        }
    }
}

# LiveWall
Живые обои (Material 3 Expressive): 10 стилей, выбор цвета, скорость, плотность.
Сборка: Android Studio -> Build APK, или `gradle assembleRelease` (Gradle 8.7, JDK 17).
APK: app/build/outputs/apk/release/app-release.apk
